import scrapy
from scrapy.conf import settings
from scrapy.selector import Selector

class indexwords(scrapy.Spider):
    name = "indexwords"
    cookie=settings['COOKIE']
    start_urls =["http://www.patentics.com/invokexml.do?sf=QueryStat&sx=cn/querystat_cn&sl=chs&ss=stat&sq=ALL/ALL&sdb=KW&sdf=w85%25n&ipi=0&foo=1&idi=1"]
    domain="http://www.patentics.com"
    headers = {
        'Connection': 'keep - alive',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.82 Safari/537.36'
    }
    #pageCounts={'us':188697}
    pageCounts = {'us': 10}
    urls={'us':'http://www.patentics.com/invokexml.do?sf=QueryStat&sx=cn/querystat_cn&sl=chs&ss=stat&sq=ALL/ALL&sdb=KW&sdf=w85%25n&ipi={0}&foo=1&idi=1'}

    def parse(self, response):
        total_page = self.pageCounts['us']
        urlstr = self.urls['us']
        for x in range(total_page):
            url = urlstr.format(x)
            yield scrapy.Request(url=url, callback=self.parse_detail, headers=self.headers, cookies=self.cookie)

    def parse_detail(self,response):
        url=response.url
        page=url[url.find("ipi=") + 4:url.find("&foo")]
        filename=settings['OUTPUT_PATH']+'indexwords-%s.csv' % page
        with open(filename,'w+') as f:
            indexwordslist=Selector(text=response.body).xpath('//w/text()').extract()
            f.writelines("%s\n" %item for item in indexwordslist)
        self.log('Saved file %s' % filename)